from JackTokenizer import JackTokenizer
from SymbolTable import SymbolTable
from VMWriter import VMWriter

SEGMENT = {
    'static': 'static',
    'field': 'this',
    'arg': 'argument',
    'var': 'local'
}

ARITH = {
    '+': 'add', '-': 'sub', '&': 'and', '|': 'or', '<': 'lt', '>': 'gt', '=': 'eq'
}

class CompilationEngine:
    def __init__(self, input_file, output_file):
        self.t = JackTokenizer(input_file)
        self.vm = VMWriter(output_file)
        self.st = SymbolTable()
        self.className = ''
        self.label_id = 0

    def close(self):
        self.vm.close()

    def eat(self, expected=None):
        tok = self.t.advance()
        if expected is not None and tok != expected:
            raise SyntaxError(f'Expected {expected}, got {tok}')
        return tok

    def new_label(self, base):
        label = f'{base}{self.label_id}'
        self.label_id += 1
        return label

    def compileClass(self):
        self.eat('class')
        self.className = self.eat()
        self.eat('{')
        while self.t.peek() in ('static', 'field'):
            self.compileClassVarDec()
        while self.t.peek() in ('constructor', 'function', 'method'):
            self.compileSubroutine()
        self.eat('}')
        self.close()

    def compileClassVarDec(self):
        kind = self.eat()
        type_ = self.eat()
        name = self.eat()
        self.st.define(name, type_, kind)
        while self.t.peek() == ',':
            self.eat(',')
            name = self.eat()
            self.st.define(name, type_, kind)
        self.eat(';')

    def compileSubroutine(self):
        sub_kind = self.eat()
        self.st.startSubroutine()
        if sub_kind == 'method':
            self.st.define('this', self.className, 'arg')
        self.eat()  # return type
        sub_name = self.eat()
        self.eat('(')
        self.compileParameterList()
        self.eat(')')
        self.eat('{')
        while self.t.peek() == 'var':
            self.compileVarDec()
        nLocals = self.st.varCount('var')
        self.vm.writeFunction(f'{self.className}.{sub_name}', nLocals)
        if sub_kind == 'constructor':
            fields = self.st.varCount('field')
            self.vm.writePush('constant', fields)
            self.vm.writeCall('Memory.alloc', 1)
            self.vm.writePop('pointer', 0)
        elif sub_kind == 'method':
            self.vm.writePush('argument', 0)
            self.vm.writePop('pointer', 0)
        self.compileStatements()
        self.eat('}')

    def compileParameterList(self):
        if self.t.peek() == ')':
            return
        type_ = self.eat()
        name = self.eat()
        self.st.define(name, type_, 'arg')
        while self.t.peek() == ',':
            self.eat(',')
            type_ = self.eat()
            name = self.eat()
            self.st.define(name, type_, 'arg')

    def compileVarDec(self):
        self.eat('var')
        type_ = self.eat()
        name = self.eat()
        self.st.define(name, type_, 'var')
        while self.t.peek() == ',':
            self.eat(',')
            name = self.eat()
            self.st.define(name, type_, 'var')
        self.eat(';')

    def compileStatements(self):
        while self.t.peek() in ('let', 'if', 'while', 'do', 'return'):
            tok = self.t.peek()
            if tok == 'let': self.compileLet()
            elif tok == 'if': self.compileIf()
            elif tok == 'while': self.compileWhile()
            elif tok == 'do': self.compileDo()
            elif tok == 'return': self.compileReturn()

    def compileLet(self):
        self.eat('let')
        name = self.eat()
        is_array = False
        if self.t.peek() == '[':
            is_array = True
            self.push_var(name)
            self.eat('[')
            self.compileExpression()
            self.eat(']')
            self.vm.writeArithmetic('add')
        self.eat('=')
        self.compileExpression()
        self.eat(';')
        if is_array:
            self.vm.writePop('temp', 0)
            self.vm.writePop('pointer', 1)
            self.vm.writePush('temp', 0)
            self.vm.writePop('that', 0)
        else:
            self.pop_var(name)

    def compileIf(self):
        self.eat('if')
        label_true = self.new_label('IF_TRUE')
        label_false = self.new_label('IF_FALSE')
        label_end = self.new_label('IF_END')
        self.eat('(')
        self.compileExpression()
        self.eat(')')
        self.vm.writeIf(label_true)
        self.vm.writeGoto(label_false)
        self.vm.writeLabel(label_true)
        self.eat('{')
        self.compileStatements()
        self.eat('}')
        if self.t.peek() == 'else':
            self.vm.writeGoto(label_end)
            self.vm.writeLabel(label_false)
            self.eat('else')
            self.eat('{')
            self.compileStatements()
            self.eat('}')
            self.vm.writeLabel(label_end)
        else:
            self.vm.writeLabel(label_false)

    def compileWhile(self):
        self.eat('while')
        label_exp = self.new_label('WHILE_EXP')
        label_end = self.new_label('WHILE_END')
        self.vm.writeLabel(label_exp)
        self.eat('(')
        self.compileExpression()
        self.eat(')')
        self.vm.writeArithmetic('not')
        self.vm.writeIf(label_end)
        self.eat('{')
        self.compileStatements()
        self.eat('}')
        self.vm.writeGoto(label_exp)
        self.vm.writeLabel(label_end)

    def compileDo(self):
        self.eat('do')
        self.compileSubroutineCall()
        self.eat(';')
        self.vm.writePop('temp', 0)

    def compileReturn(self):
        self.eat('return')
        if self.t.peek() != ';':
            self.compileExpression()
        else:
            self.vm.writePush('constant', 0)
        self.eat(';')
        self.vm.writeReturn()

    def compileExpression(self):
        self.compileTerm()
        while self.t.peek() in ['+', '-', '*', '/', '&', '|', '<', '>', '=']:
            op = self.eat()
            self.compileTerm()
            if op == '*':
                self.vm.writeCall('Math.multiply', 2)
            elif op == '/':
                self.vm.writeCall('Math.divide', 2)
            else:
                self.vm.writeArithmetic(ARITH[op])

    def compileTerm(self):
        tok = self.t.peek()
        typ = self.t.tokenType(tok)
        if typ == 'INT_CONST':
            self.vm.writePush('constant', int(self.eat()))
        elif typ == 'STRING_CONST':
            s = self.eat()[1:-1]
            self.vm.writePush('constant', len(s))
            self.vm.writeCall('String.new', 1)
            for ch in s:
                self.vm.writePush('constant', ord(ch))
                self.vm.writeCall('String.appendChar', 2)
        elif tok in ('true', 'false', 'null', 'this'):
            self.eat()
            if tok == 'true':
                self.vm.writePush('constant', 0)
                self.vm.writeArithmetic('not')
            elif tok in ('false', 'null'):
                self.vm.writePush('constant', 0)
            else:
                self.vm.writePush('pointer', 0)
        elif tok == '(':
            self.eat('(')
            self.compileExpression()
            self.eat(')')
        elif tok in ('-', '~'):
            op = self.eat()
            self.compileTerm()
            self.vm.writeArithmetic('neg' if op == '-' else 'not')
        else:
            name = self.eat()
            if self.t.peek() == '[':
                self.push_var(name)
                self.eat('[')
                self.compileExpression()
                self.eat(']')
                self.vm.writeArithmetic('add')
                self.vm.writePop('pointer', 1)
                self.vm.writePush('that', 0)
            elif self.t.peek() in ('(', '.'):
                self.compileSubroutineCall(name)
            else:
                self.push_var(name)

    def compileExpressionList(self):
        n = 0
        if self.t.peek() == ')':
            return n
        self.compileExpression()
        n += 1
        while self.t.peek() == ',':
            self.eat(',')
            self.compileExpression()
            n += 1
        return n

    def compileSubroutineCall(self, first_name=None):
        name = first_name if first_name is not None else self.eat()
        nArgs = 0
        if self.t.peek() == '.':
            self.eat('.')
            second = self.eat()
            kind = self.st.kindOf(name)
            if kind:
                self.push_var(name)
                nArgs += 1
                full_name = f'{self.st.typeOf(name)}.{second}'
            else:
                full_name = f'{name}.{second}'
        else:
            self.vm.writePush('pointer', 0)
            nArgs += 1
            full_name = f'{self.className}.{name}'
        self.eat('(')
        nArgs += self.compileExpressionList()
        self.eat(')')
        self.vm.writeCall(full_name, nArgs)

    def push_var(self, name):
        kind = self.st.kindOf(name)
        index = self.st.indexOf(name)
        if kind is None:
            raise NameError(f'Unknown variable {name}')
        self.vm.writePush(SEGMENT[kind], index)

    def pop_var(self, name):
        kind = self.st.kindOf(name)
        index = self.st.indexOf(name)
        if kind is None:
            raise NameError(f'Unknown variable {name}')
        self.vm.writePop(SEGMENT[kind], index)

class VMWriter:
    def __init__(self, output_file):
        self.f = open(output_file, 'w')

    def writePush(self, segment, index):
        self.f.write(f'push {segment} {index}\n')

    def writePop(self, segment, index):
        self.f.write(f'pop {segment} {index}\n')

    def writeArithmetic(self, command):
        self.f.write(command + '\n')

    def writeLabel(self, label):
        self.f.write(f'label {label}\n')

    def writeGoto(self, label):
        self.f.write(f'goto {label}\n')

    def writeIf(self, label):
        self.f.write(f'if-goto {label}\n')

    def writeCall(self, name, nArgs):
        self.f.write(f'call {name} {nArgs}\n')

    def writeFunction(self, name, nLocals):
        self.f.write(f'function {name} {nLocals}\n')

    def writeReturn(self):
        self.f.write('return\n')

    def close(self):
        self.f.close()

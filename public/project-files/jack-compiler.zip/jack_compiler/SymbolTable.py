class SymbolTable:
    def __init__(self):
        self.class_scope = {}
        self.sub_scope = {}
        self.counts = {'static': 0, 'field': 0, 'arg': 0, 'var': 0}

    def startSubroutine(self):
        self.sub_scope = {}
        self.counts['arg'] = 0
        self.counts['var'] = 0

    def define(self, name, type_, kind):
        index = self.counts[kind]
        self.counts[kind] += 1
        entry = {'type': type_, 'kind': kind, 'index': index}
        if kind in ('static', 'field'):
            self.class_scope[name] = entry
        else:
            self.sub_scope[name] = entry

    def varCount(self, kind):
        return self.counts[kind]

    def _lookup(self, name):
        if name in self.sub_scope:
            return self.sub_scope[name]
        if name in self.class_scope:
            return self.class_scope[name]
        return None

    def kindOf(self, name):
        e = self._lookup(name)
        return e['kind'] if e else None

    def typeOf(self, name):
        e = self._lookup(name)
        return e['type'] if e else None

    def indexOf(self, name):
        e = self._lookup(name)
        return e['index'] if e else None

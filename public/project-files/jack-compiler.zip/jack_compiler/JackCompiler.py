import os
import sys
from CompilationEngine import CompilationEngine

def compile_file(path):
    if not path.endswith('.jack'):
        return
    out_path = path[:-5] + '.vm'
    engine = CompilationEngine(path, out_path)
    print(f'Compiled {path} -> {out_path}')

def main():
    if len(sys.argv) != 2:
        print('Usage: python3 JackCompiler.py <file.jack | folder>')
        sys.exit(1)

    path = sys.argv[1]
    if os.path.isdir(path):
        for filename in os.listdir(path):
            if filename.endswith('.jack'):
                compile_file(os.path.join(path, filename))
    else:
        compile_file(path)

if __name__ == '__main__':
    main()

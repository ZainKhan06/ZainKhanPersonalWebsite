# Jack Compiler for nand2tetris

This compiler converts Jack code into VM code.

## Run on one file
```bash
python3 JackCompiler.py Main.jack
```

## Run on a folder
```bash
python3 JackCompiler.py Square/
```

It creates `.vm` files next to the `.jack` files.

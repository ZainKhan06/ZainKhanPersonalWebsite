import re

KEYWORDS = {
    'class','constructor','function','method','field','static','var','int','char','boolean',
    'void','true','false','null','this','let','do','if','else','while','return'
}
SYMBOLS = set('{}()[].,;+-*/&|<>=~')

class JackTokenizer:
    def __init__(self, input_file):
        with open(input_file, 'r') as f:
            text = f.read()
        text = self._remove_comments(text)
        self.tokens = self._tokenize(text)
        self.i = 0

    def _remove_comments(self, text):
        text = re.sub(r'/\*.*?\*/', '', text, flags=re.S)
        text = re.sub(r'//.*', '', text)
        return text

    def _tokenize(self, text):
        tokens = []
        i = 0
        while i < len(text):
            c = text[i]
            if c.isspace():
                i += 1
            elif c == '"':
                j = i + 1
                while j < len(text) and text[j] != '"':
                    j += 1
                tokens.append(text[i:j+1])
                i = j + 1
            elif c in SYMBOLS:
                tokens.append(c)
                i += 1
            else:
                j = i
                while j < len(text) and (not text[j].isspace()) and text[j] not in SYMBOLS and text[j] != '"':
                    j += 1
                tokens.append(text[i:j])
                i = j
        return tokens

    def hasMoreTokens(self):
        return self.i < len(self.tokens)

    def advance(self):
        tok = self.tokens[self.i]
        self.i += 1
        return tok

    def peek(self):
        if self.i < len(self.tokens):
            return self.tokens[self.i]
        return None

    def peek_next(self):
        if self.i + 1 < len(self.tokens):
            return self.tokens[self.i + 1]
        return None

    def tokenType(self, token):
        if token in KEYWORDS:
            return 'KEYWORD'
        if token in SYMBOLS:
            return 'SYMBOL'
        if token.startswith('"') and token.endswith('"'):
            return 'STRING_CONST'
        if token.isdigit():
            return 'INT_CONST'
        return 'IDENTIFIER'
